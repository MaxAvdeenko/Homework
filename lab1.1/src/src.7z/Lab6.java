import java.util.Scanner;

public class Lab6 {

	public static void main(String... args) {
		Scanner in = new Scanner(System.in);
		Integer number = in.nextInt(); 
		String convert = Integer.toHexString(number);
		System.out.println(convert);
	}
}
